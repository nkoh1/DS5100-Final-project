print("Successfully installed the MonteCarlo package!!")
